export { default as getDepartmentList } from "./useGetDepartment";
export { default as getALLDepartmentList } from "../designation/useGetDepartmentDropdown";
