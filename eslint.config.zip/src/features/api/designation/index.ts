export { default as addUpdateDesignation } from "./useAddDesignation";
export { default as deleteDesignationMutation } from "./useDeleteDesignation";
export { default as getDesignationList } from "./useGetDesignation";
export { default as getDesignationDropdown } from "./useGetDropdownDesignation";
