export { default as addUpdateEmployee } from "./useAddEmployee";
export { default as getEmployee } from "./useGetEmployee";
export { default as deleteEmployee } from "./useDeleteEmployee";
export { default as ddAllEmployee } from "./useDdEmployee";

export { default as useGetEmployeeLog } from "./useGetEmployeeLog";
export { default as useGetEmployeeDd } from "./useGetEmployeeDd";
