import Api from "@/features/utils/api.utils";
import Urls from "@/features/utils/urls.utils";
import { useQuery } from "@tanstack/react-query";

type IssueRes = BaseResponse<IssuesProps>;

export default function useGetIssues({ filter }: FilterDataProps) {
  const query = useQuery({
    queryKey: ["get-issues-list", filter],
    queryFn: async () => {
      const { data: resData } = await Api.post<IssueRes>({
        url: Urls.getIssues(),
        data: {
          ...filter,
        },
      });

      return resData;
    },
  });
  return query;
}
