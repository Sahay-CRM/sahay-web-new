export { default as getMeetingType } from "./useGetMeetingType";
