export { default } from "./addEmployee";
