export { default } from "./KpiTable";
