export { default } from "./addDetailMeeting";
