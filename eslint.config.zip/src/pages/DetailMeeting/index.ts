export { default } from "./detailMeetingList";
