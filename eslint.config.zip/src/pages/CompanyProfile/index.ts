export { default } from "./companyProfile";
