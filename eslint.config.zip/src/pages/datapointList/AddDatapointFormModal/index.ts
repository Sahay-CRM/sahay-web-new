export { default } from "./addDatapoint";
