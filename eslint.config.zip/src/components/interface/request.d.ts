interface CreateRequest {
  changeRequestId?: string;
  requestType?: string;
  requesterId?: string;
  requestTitle?: string;
  requesterNote?: string;
  reviewerId?: string;
  reviewerNote?: string;
  reviewRefId?: string;
  requestStatus?: string;
  requesterName?: string;
  reviewerName?: string;
}

interface RequestFormValues {
  requestName: string;
  notes: string;
  requestType?: string;
}
