import React from "react";

interface ProgressBarProps {
  total: number;
  completed: number;
  showPercentage?: boolean;
  height?: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  total,
  completed,
  showPercentage = true,
  height = 16,
}) => {
  const completedPercentage = total > 0 ? (completed / total) * 100 : 0;
  const safeCompletedPercentage = Math.min(completedPercentage, 100);

  return (
    <div className="w-full">
      <div
        className="relative w-full bg-gray-200 mt-4 rounded-full overflow-hidden"
        style={{ height: `${height}px` }}
      >
        {/* Gradient Fill */}
        <div
          className="absolute top-0 left-0 h-full transition-all duration-500 ease-out rounded-full bg-gradient-to-r from-green-300 via-green-600 to-green-700"
          style={{ width: `${safeCompletedPercentage}%` }}
        />

        {showPercentage && (
          <>
            {completed !== total && (
              <>
                {/* {safeCompletedPercentage > 20 && ( */}
                <div className="absolute left-2 top-1/2 -translate-y-1/2 text-xs font-medium text-black">
                  {completed}
                </div>
                {/* )} */}
                {/* Total number on the right */}
                <div className="absolute right-2 top-1/2 -translate-y-1/2 text-xs font-medium text-gray-600">
                  {total}
                </div>
              </>
            )}
          </>
        )}
      </div>
      <div className="text-xs font-medium mt-1.5 text-black">
        {total} of {completed} Items Completed
      </div>
    </div>
  );
};

export default ProgressBar;
