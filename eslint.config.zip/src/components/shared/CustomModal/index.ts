export { default } from "./CustomModal";
