export { default } from "./permissionTable";
