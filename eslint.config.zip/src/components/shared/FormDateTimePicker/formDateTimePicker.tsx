import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { CalendarIcon } from "lucide-react";
import { FormLabel } from "@/components/ui/form";
import { twMerge } from "tailwind-merge";

interface Props {
  label: string;
  value: Date | string | null;
  onChange: (date: Date | null) => void;
  error?: { message?: string };
  isMandatory?: boolean;
  timeZone?: string;
  disableDaysFromToday?: number;
  disablePastDates?: boolean;
  labelClass?: string;
  hideTime?: boolean;
}

export default function FormDateTimePicker({
  label,
  value,
  onChange,
  error,
  isMandatory,
  disableDaysFromToday = 0,
  disablePastDates = false,
  labelClass,
  hideTime = false,
}: Props) {
  const dateValue = typeof value === "string" ? new Date(value) : value;

  const filterDate = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const compareDate = new Date(date);
    compareDate.setHours(0, 0, 0, 0);

    if (disablePastDates && compareDate.getTime() < today.getTime()) {
      return false;
    }

    if (disableDaysFromToday === 0) {
      return true;
    }

    const disableUntilDate = new Date(today);
    disableUntilDate.setDate(today.getDate() + disableDaysFromToday);

    return compareDate.getTime() > disableUntilDate.getTime();
  };

  const handleChange = (date: Date | null) => {
    if (!date) {
      onChange(date);
      return;
    }

    if (!hideTime) {
      const pickedDate = new Date(date);
      if (pickedDate.getHours() === 0 && pickedDate.getMinutes() === 0) {
        pickedDate.setHours(18, 0, 0, 0); // 6:00 PM
      }
      onChange(pickedDate);
    } else {
      // When time is hidden, just pass the date as is
      onChange(date);
    }

    // const pickedDate = new Date(date);
    // if (pickedDate.getHours() === 0 && pickedDate.getMinutes() === 0) {
    //   pickedDate.setHours(18, 0, 0, 0); // 6:00 PM
    // }

    // onChange(pickedDate);
  };

  return (
    <div className="w-full">
      {label && (
        <FormLabel className={twMerge("mb-4", labelClass)}>
          {label}{" "}
          {isMandatory && <span className="text-red-500 text-[20px]">*</span>}
        </FormLabel>
      )}
      <div className="relative w-full min-w-0">
        <DatePicker
          selected={dateValue}
          onChange={handleChange}
          showTimeSelect={!hideTime}
          timeFormat={hideTime ? undefined : "h:mm aa"}
          dateFormat={hideTime ? "dd/MM/yyyy" : "dd/MM/yyyy h:mm aa"}
          placeholderText={hideTime ? "Select date" : "Select date and time"}
          className="border px-10 py-1.5 rounded-md w-full text-sm sm:text-base"
          portalId="root"
          popperClassName="responsive-datepicker-popper"
          filterDate={filterDate}
        />
        <CalendarIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" />
      </div>
      {error && <span className="text-red-500 text-sm">{error.message}</span>}
      <style>
        {`
          .responsive-datepicker-popper {
            z-index: 9999;
            min-width: 0;
            width: auto;
            max-width: 95vw;
          }
          .responsive-datepicker-popper .react-datepicker {
            min-width: 0;
            width: auto;
            max-width: 95vw;
          }
            .react-datepicker-wrapper {
            width: 100%;
            }
          @media (max-width: 640px) {
            .responsive-datepicker-popper .react-datepicker {
              font-size: 14px;
              width: 95vw;
              min-width: 0;
            }
            .responsive-datepicker-popper .react-datepicker__time-container {
              width: 100px;
              min-width: 0;
            }
          }
        `}
      </style>
    </div>
  );
}
