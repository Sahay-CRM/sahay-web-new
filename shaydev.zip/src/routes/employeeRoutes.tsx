import DashboardLayout from "@/features/layouts/DashboardLayout/dashboardLayout";
import AddCompanyEmployee from "@/pages/companyEmployee/AddCompanyEmployee";
import { lazy } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

const Dashboard = lazy(() => import("../pages/homePage/HomePage"));
const Theme = lazy(() => import("../pages/theme/Theme"));
const companydesignation = lazy(
  () => import("../pages/companyDesignation/companyDesignation")
);
const companyemployee = lazy(
  () => import("../pages/companyEmployee/companyEmployee")
);
const CompanyImportantDates = lazy(
  () => import("../pages/companyImportantDates/CompanyImportantDates")
);
const CompanyMeeting = lazy(() => import("../pages/Meeting/MeetingList"));
const CompanyTask = lazy(() => import("../pages/companyTask/CompanyTaskList"));
const CompanyProjects = lazy(
  () => import("../pages/companyProjects/CompanyProjects")
);
const DatapointList = lazy(
  () => import("../pages/datapointList/DatapointList")
);
const userpermissionlist = lazy(
  () => import("../pages/Roles/Userpermissionlist")
);

export default function EmployeeRoutes() {
  return (
    <Routes>
      <Route index element={<Navigate to="/dashboard" replace />} />
      <Route path="/dashboard" element={<DashboardLayout />}>
        <Route index Component={Dashboard} />
        <Route path="settings" Component={Theme} />
        <Route path="company-designation" Component={companydesignation} />
        <Route path="company-employee" Component={companyemployee} />
        {/* ✅ Move these two inside */}
        <Route path="employees/add" element={<AddCompanyEmployee />} />
        {/* <Route
          path="employees/edit/:id"
          element={<AddCompanyEmployee isEditMode />}
        /> */}
        <Route
          path="company-important-dates"
          Component={CompanyImportantDates}
        />
        <Route path="meeting" Component={CompanyMeeting} />
        <Route path="tasks" Component={CompanyTask} />
        <Route path="projects" Component={CompanyProjects} />
        <Route path="datapoint" Component={DatapointList} />
        <Route path="roles/userpermissionlist" Component={userpermissionlist} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
