import { FormProvider } from "react-hook-form";
import { Button } from "@/components/ui/button";
import StepProgress from "@/components/shared/StepFom/StepForm";
import FormInputField from "@/components/shared/Form/FormInput/FormInputField";
import FormSelect from "@/components/shared/Form/FormSelect/selectuser";
import { useAddCompanyEmployee } from "./useAddCompanyEmployee";

import { useNavigate, useParams } from "react-router-dom";

export default function AddCompanyEmployee() {
  const navigate = useNavigate();
  const { id } = useParams(); // for edit
  const isEditMode = Boolean(id);

  const {
    step,
    nextStep,
    prevStep,
    steps,
    methods,
    onSubmit,
    departmentData,
    designationData,
    employees,
    countryCode,
    setCountryCode,
  } = useAddCompanyEmployee({
    initialData: null, // fetch from API if needed
    isEditMode,
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = methods;

  const handleClose = () => {
    reset();
    navigate("/dashboard/company-employee");
  };

  const handleFormSubmit = async (data) => {
    const success = await onSubmit(data);
    if (success) {
      handleClose();
    }
  };

  return (
    <div className="w-full px-2 overflow-x-auto sm:px-4 py-4">
      <h1 className="text-2xl font-semibold mb-4">
        {isEditMode ? "Edit Employee" : "Add Employee"}
      </h1>

      <FormProvider {...methods}>
        <StepProgress currentStep={step} totalSteps={2} stepNames={steps} />
        {step === 1 && (
          <div className="grid grid-cols-2 gap-4 mt-4">
            <FormInputField
              label="Employee Name"
              {...register("employeeName", { required: "Name is required" })}
              error={errors.employeeName}
            />
            <FormInputField
              label="Email"
              {...register("employeeEmail", {
                required: "Email is required",
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: "Enter valid email",
                },
              })}
              error={errors.employeeEmail}
            />
            <FormInputField
              id="mobile"
              label="Mobile Number"
              {...register("mobile", {
                required: "Please enter your mobile number",
              })}
              error={errors.employeeMobile}
              placeholder="Enter mobile number"
              options={[{ value: "+91", label: "+91" }]}
              selectedCodeValue={countryCode || "+91"}
              onCountryCodeChange={setCountryCode}
              className="text-lg"
            />
            <FormSelect
              label="Department"
              name="departmentId"
              options={departmentData}
              error={errors.departmentId}
            />
            <FormSelect
              label="Designation"
              name="designationId"
              options={designationData}
              error={errors.designationId}
            />
          </div>
        )}

        {step === 2 && employees.length > 0 && (
          <div className="mt-4">
            <FormSelect
              label="Reporting Manager"
              name="reportingManagerId"
              options={employees}
              error={errors.reportingManagerId}
            />
          </div>
        )}

        <div className="mt-6 flex gap-2 justify-end">
          {step > 1 && <Button onClick={prevStep}>Back</Button>}
          {step < 2 ? (
            <Button onClick={nextStep}>Next</Button>
          ) : (
            <Button onClick={handleSubmit(handleFormSubmit)}>
              {isEditMode ? "Update" : "Submit"}
            </Button>
          )}
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
        </div>
      </FormProvider>
    </div>
  );
}
