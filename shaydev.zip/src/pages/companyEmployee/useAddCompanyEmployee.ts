// hooks/useAddCompanyEmployee.ts
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import { useAuth } from "@/features/auth/useAuth";
import { baseUrl } from "@/features/utils/urls.utils";
import { toast, Toaster } from "sonner";

export function useAddCompanyEmployee({ initialData, isEditMode }) {
  const methods = useForm();
  const { register, reset } = methods;
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [countryCode, setCountryCode] = useState("+91");

  const [departmentData, setDepartmentData] = useState([]);
  const [designationData, setDesignationData] = useState([]);
  const [employees, setEmployees] = useState([]);

  const nextStep = () => setStep((prev) => prev + 1);
  const prevStep = () => setStep((prev) => prev - 1);
  const steps = ["Employee Info", "Manager Info"];

  const fetchOptions = useCallback(async () => {
    const fetcher = async (url, mapFn) => {
      const res = await axios.get(url, {
        headers: { Authorization: user?.token },
      });
      return res.data?.data.map(mapFn) ?? [];
    };
    const dep = fetcher(`${baseUrl}/departments`, (d) => ({
      value: d.departmentId,
      label: d.departmentName,
    }));
    const des = fetcher(`${baseUrl}/company/designation/all`, (d) => ({
      value: d.designationId,
      label: d.designationName,
    }));
    const emp = fetcher(`${baseUrl}/company/employee/all`, (e) => ({
      value: e.employeeId,
      label: e.employeeName,
    }));
    [dep, des, emp].forEach(async (promise, i) => {
      try {
        const data = await promise;
        if (i === 0) setDepartmentData(data);
        else if (i === 1) setDesignationData(data);
        else if (i === 2) setEmployees(data);
      } catch (_) {}
    });
  }, [user?.token]);

  const getCompanyEmployeeById = useCallback(async () => {
    if (!initialData?.employeeId) return;
    try {
      const res = await axios.get(
        `${baseUrl}/company/employee/${initialData.employeeId}`,
        {
          headers: { Authorization: user?.token },
        }
      );
      const de = res.data.data;
      const countryCode = de.employeeMobile?.match(/^\+91/)?.[0] ?? "+91";
      const mobileNo = de.employeeMobile?.replace(/^\+91/, "");

      setCountryCode(countryCode);
      reset({
        employeeName: de.employeeName,
        employeeEmail: de.employeeEmail,
        employeeMobile: mobileNo,
        reportingManagerId: de.reportingManager
          ? {
              value: de.reportingManager.employeeId,
              label: de.reportingManager.employeeName,
            }
          : null,
        departmentId: de.department
          ? {
              value: de.department.departmentId,
              label: de.department.departmentName,
            }
          : null,
        designationId: de.designation
          ? {
              value: de.designation.designationId,
              label: de.designation.designationName,
            }
          : null,
      });
    } catch {
      toast.error("Something went wrong!");
    }
  }, [initialData, reset, user?.token]);

  useEffect(() => {
    fetchOptions();
    if (isEditMode) getCompanyEmployeeById();
  }, [fetchOptions, getCompanyEmployeeById, isEditMode]);

  const onSubmit = async (data) => {
    try {
      const method = isEditMode ? "put" : "post";
      const url = isEditMode
        ? `${baseUrl}/company/employee/${initialData.employeeId}`
        : `${baseUrl}/company/employee`;
      const saveObject = {
        employeeName: data.employeeName,
        employeeEmail: data.employeeEmail,
        employeeMobile: countryCode + data.employeeMobile,
        departmentId: data.departmentId.value,
        designationId: data.designationId.value,
        reportingManagerId: data.reportingManagerId.value,
      };
      const res = await axios({
        method,
        url,
        data: saveObject,
        headers: {
          "Content-Type": "application/json",
          Authorization: user?.token,
        },
      });
      if (res.data.status === true) {
        toast.success(res.data.message);
        return true;
      } else {
        toast.error(res.data.message);
      }
    } catch (e) {
      toast.error(e?.response?.data?.message ?? "Something went wrong!");
    }
    return false;
  };

  return {
    step,
    nextStep,
    prevStep,
    steps,
    methods,
    onSubmit,
    departmentData,
    designationData,
    employees,
    countryCode,
    setCountryCode,
  };
}
