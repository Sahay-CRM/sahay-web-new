import ThemeSettingsPage from "@/components/shared/Theme/ThemeSetting";

export default function ThemeSetting() {
  return (
    <>
      <ThemeSettingsPage />
    </>
  );
}
