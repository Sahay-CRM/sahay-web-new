function HomePage() {
  return (
    <div className="">
      <p>Home Screen</p>
    </div>
  );
}

export default HomePage;
