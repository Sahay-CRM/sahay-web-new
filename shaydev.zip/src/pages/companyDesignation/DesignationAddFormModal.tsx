import React, { useCallback, useEffect, useState } from "react";
import { useFormContext } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import ModalData from "@/components/shared/Modal/ModalData";
import FormSelect from "@/components/shared/Form/FormSelect/selectuser";
import axios from "axios";
import { baseUrl } from "@/features/utils/urls.utils";
import { useAuth } from "@/features/auth/useAuth";

interface DesignationAddFormModalProps {
  isModalOpen: boolean;
  modalClose: () => void;
  modalData?: undefined;
}

const DesignationAddFormModal: React.FC<DesignationAddFormModalProps> = ({
  isModalOpen,
  modalClose,
  modalData,
}) => {
  const { register, handleSubmit, reset, setValue } = useFormContext();
  const { user } = useAuth();
  const [departmentData, setDepartmentData] = useState([]);

  const onSubmit = (data: undefined) => {
    console.log("Submitted Data:", data);
    modalClose();
    reset();
  };

  const getDepartmentData = useCallback(async () => {
    try {
      if (!user?.token) {
        setDepartmentData([]);
        return;
      }
      const res = await axios.get(`${baseUrl}/departments`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: user.token,
        },
      });
      if (res.data) {
        const updatedData = res.data.data.map((el) => ({
          value: el.departmentId,
          label: el.departmentName,
        }));
        setDepartmentData(updatedData);
      }
    } catch () {
      setDepartmentData([]);
    }
  }, [user?.token]);

  useEffect(() => {
    getDepartmentData();
  }, [getDepartmentData]);

  useEffect(() => {
    if (modalData) {
      reset({
        designationName: modalData.designationName || "",
        departmentId: modalData.department?.departmentId || "",
      });
    } else {
      reset({
        designationName: "",
        departmentId: "",
      });
    }
  }, [modalData, reset]);

  return (
    <ModalData
      isModalOpen={isModalOpen}
      modalClose={modalClose}
      modalTitle={
        modalData && Object.keys(modalData).length > 0
          ? "Edit Designation"
          : "Add Designation"
      }
      buttons={[
        {
          btnText: "Cancel",
          btnClick: modalClose,
        },
        {
          btnText:
            modalData && Object.keys(modalData).length > 0 ? "Update" : "Add",
          btnClick: handleSubmit(onSubmit),
        },
      ]}
    >
      <div className="space-y-4">
        <FormSelect
          label="Department"
          id="departmentId"
          options={departmentData}
          isMandatory
          value=""
          // ✅ Set value on change
          onChange={(e) => setValue("departmentId", e.target.value)}
          // ✅ Refresh data on focus
          onFocus={getDepartmentData}
        />
        <div>
          <Label htmlFor="designationName" className="mb-2">
            Designation Name
          </Label>
          <Input
            id="designationName"
            placeholder="Enter designation name"
            {...register("designationName", { required: true })}
          />
        </div>
      </div>
    </ModalData>
  );
};

export default DesignationAddFormModal;
